# Scheme Saathi - setup

## 1. Install Docker first (this script does NOT install it)
- Windows / macOS: Docker Desktop - https://www.docker.com/products/docker-desktop/  (start it, wait for "Engine running")
- Linux: Docker Engine + Compose v2 - https://docs.docker.com/engine/install/

## 2. Extract this folder, open a terminal in it, run ONE command

| OS | Command |
|----|---------|
| Windows (PowerShell or CMD) | `powershell -ExecutionPolicy Bypass -File .\install.ps1` |
| macOS / Linux (Terminal) | `bash install.sh` |

It asks only for your OPENROUTER_API_KEY, writes a readable `.env`, pulls the images from Docker Hub,
starts everything, and prints:

- Streamlit app: http://localhost:8501
- Grafana:       http://localhost:3000  (login `admin` + the password shown at the end)

Stop: `docker compose down` | Logs: `docker compose logs -f`
To change settings, edit `.env`, then run `docker compose up -d`.
Add `http://localhost:8501` to Allowed Callback URLs in your Auth0 application.
