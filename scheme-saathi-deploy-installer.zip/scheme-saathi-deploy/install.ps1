# Scheme Saathi - one-command setup for Windows (PowerShell 5.1 or newer).
# Prerequisite: Docker Desktop installed and running.
# Run:  powershell -ExecutionPolicy Bypass -File .\install.ps1
$ErrorActionPreference = 'Continue'
Set-Location $PSScriptRoot

function Say($m) { Write-Host ""; Write-Host "==> $m" -ForegroundColor Cyan }
function Die($m) { Write-Host ""; Write-Host "ERROR: $m" -ForegroundColor Red; exit 1 }

# ---------------- 1. Check Docker (we do NOT install it) ----------------
$bin = Join-Path $env:ProgramFiles 'Docker\Docker\resources\bin'
if (Test-Path $bin) { $env:Path = "$env:Path;$bin" }

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Host ""
  Write-Host "Docker Desktop is not installed." -ForegroundColor Yellow
  Write-Host ""
  Write-Host "  1. Install it from: https://www.docker.com/products/docker-desktop/"
  Write-Host "  2. Start Docker Desktop and wait until it shows 'Engine running'."
  Write-Host "  3. Run again:  powershell -ExecutionPolicy Bypass -File .\install.ps1"
  Write-Host ""
  exit 1
}
cmd /c "docker info >nul 2>&1"
if ($LASTEXITCODE -ne 0) {
  Die "Docker Desktop is installed but not running. Start it, wait for 'Engine running', then run this command again."
}
cmd /c "docker compose version >nul 2>&1"
if ($LASTEXITCODE -ne 0) { Die "Docker Compose v2 is missing. Update Docker Desktop to the latest version." }

# ---------------- 2. Ask for the key + write .env ----------------
function GetV($k) {
  if (Test-Path .env) {
    $l = Select-String -Path .env -Pattern "^$k=" | Select-Object -First 1
    if ($l) { return ($l.Line.Substring($k.Length + 1)).Trim().Trim("'") }
  }
  return ''
}
function Dflt($k, $d) { $v = GetV $k; if ($v) { $v } else { $d } }
function Q($v) { if ($v -match '^[A-Za-z0-9._/:@+=,-]*$') { $v } else { "'$v'" } }
function Rand($n) {
  $b = New-Object byte[] $n
  $r = [Security.Cryptography.RandomNumberGenerator]::Create(); $r.GetBytes($b)
  [Convert]::ToBase64String($b).Replace('+','-').Replace('/','_').TrimEnd('=')
}

$old = GetV 'OPENROUTER_API_KEY'
$key = $env:OPENROUTER_API_KEY
Say "Configuration"
while (-not $key) {
  if ($old) { $p = "Enter OPENROUTER_API_KEY (required) [Enter = keep saved key]" }
  else      { $p = "Enter OPENROUTER_API_KEY (required, input hidden - paste and press Enter)" }
  $sec = Read-Host $p -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
  $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
  $key = ($key -replace '\s', '')
  if (-not $key) { $key = $old }
  if (-not $key) { Write-Host "OPENROUTER_API_KEY cannot be empty." -ForegroundColor Yellow }
}
if ($key.Contains("'")) { Die "The key must not contain a single quote (')." }

$gpw = 'Snehal@123'   # fixed demo password; Grafana is reachable only from this machine
$mtk = GetV 'METRICS_BEARER_TOKEN';   if (-not $mtk) { $mtk = Rand 32 }

$lines = @(
'# ============================================================',
'#  Scheme Saathi settings  (created by install.ps1)',
'#  Edit with Notepad or any editor, then apply with:',
'#      docker compose up -d',
'# ============================================================',
'',
'# --- REQUIRED: your OpenRouter API key -----------------------',
"OPENROUTER_API_KEY=$(Q $key)",
'',
'# --- Optional: OpenAI key (leave empty if unused) ------------',
"OPENAI_API_KEY=$(Q (GetV 'OPENAI_API_KEY'))",
'',
'# --- AI models -----------------------------------------------',
"SUPERVISOR_MODEL=$(Q (Dflt 'SUPERVISOR_MODEL' 'openai/gpt-4.1-mini'))",
"SPECIALIST_MODEL=$(Q (Dflt 'SPECIALIST_MODEL' 'openai/gpt-4.1-mini'))",
'',
'# --- Login (Auth0) -------------------------------------------',
"AUTH0_DOMAIN=$(Q (Dflt 'AUTH0_DOMAIN' 'dev-pik1p86eoq2s0sbx.us.auth0.com'))",
"AUTH0_CLIENT_ID=$(Q (Dflt 'AUTH0_CLIENT_ID' 'Mzk823q6jURSZvJPeLi5yq4JQykyv7o4'))",
"AUTH0_AUDIENCE=$(Q (Dflt 'AUTH0_AUDIENCE' 'https://scheme-saathi-api'))",
"AUTH0_HOUSEHOLD_CLAIM=$(Q (Dflt 'AUTH0_HOUSEHOLD_CLAIM' 'https://scheme-saathi/household_id'))",
'AUTH0_REDIRECT_URI=http://localhost:8501',
'',
'# --- Dashboard (Grafana + Prometheus) ------------------------',
'OBSERVABILITY_ENABLED=true',
"GRAFANA_ADMIN_PASSWORD=$(Q $gpw)",
"METRICS_BEARER_TOKEN=$(Q $mtk)"
)
$utf8 = New-Object System.Text.UTF8Encoding $false
[IO.File]::WriteAllText((Join-Path $PSScriptRoot '.env'), (($lines -join "`n") + "`n"), $utf8)
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'prometheus\metrics_token'), $mtk, $utf8)

# ---------------- 3. Pull images and start ----------------
Say "Pulling images from Docker Hub (this can take a few minutes)"
docker compose pull
if ($LASTEXITCODE -ne 0) {
  Write-Host "Pull failed - retrying with linux/amd64 images (needed on some ARM machines)..."
  $env:DOCKER_DEFAULT_PLATFORM = 'linux/amd64'
  docker compose pull
  if ($LASTEXITCODE -ne 0) { Die "Could not pull images. Check your internet connection and that Docker Desktop is running." }
}

Say "Starting containers"
docker compose up -d
if ($LASTEXITCODE -ne 0) { Die "Could not start containers. If a port is busy, free ports 8501, 3000 and 9090 and run again." }

Say "Waiting for the apps to come up"
$ok = $true
foreach ($url in 'http://localhost:8501', 'http://localhost:3000/login') {
  $up = $false
  for ($i = 0; $i -lt 60; $i++) {
    try { Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 3 | Out-Null; $up = $true; break }
    catch { Start-Sleep -Seconds 3 }
  }
  if (-not $up) { $ok = $false }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  Scheme Saathi installed successfully" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  Streamlit app : http://localhost:8501"
Write-Host "  Grafana       : http://localhost:3000"
Write-Host "                  login: admin / $gpw"
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  Stop: docker compose down      Logs: docker compose logs -f"
Write-Host "  Auth0: add http://localhost:8501 to Allowed Callback URLs."
if (-not $ok) { Write-Host "  (An app was slow to respond - give it a minute, or check: docker compose logs)" -ForegroundColor Yellow }
