#!/usr/bin/env bash
# Scheme Saathi - one-command setup for macOS and Linux.
# Prerequisite: Docker Desktop (macOS) or Docker Engine + Compose v2 (Linux), installed and running.
# Run:  bash install.sh
set -u
cd "$(dirname "$0")" || exit 1

say()  { printf '\n==> %s\n' "$*"; }
die()  { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
OS="$(uname -s)"

# ---------------- 1. Check Docker (we do NOT install it) ----------------
if ! command -v docker >/dev/null 2>&1; then
  printf '\nDocker is not installed.\n\n'
  if [ "$OS" = "Darwin" ]; then
    echo "  Install Docker Desktop for Mac: https://www.docker.com/products/docker-desktop/"
    echo "  Open it, wait until it shows 'Engine running', then run:  bash install.sh"
  else
    echo "  Install Docker Engine + Compose v2: https://docs.docker.com/engine/install/"
    echo "  Then run:  bash install.sh"
  fi
  echo; exit 1
fi

USE_SUDO=0
INFO="$(docker info 2>&1)"
if [ $? -ne 0 ]; then
  if printf '%s' "$INFO" | grep -qi 'permission denied'; then
    USE_SUDO=1
    echo "Note: your user cannot talk to Docker directly; using sudo (you may be asked for your password)."
    sudo docker info >/dev/null 2>&1 || die "Docker is not running. Start it and re-run."
  else
    if [ "$OS" = "Darwin" ]; then
      die "Docker is installed but not running. Open Docker Desktop, wait for 'Engine running', then re-run: bash install.sh"
    else
      die "Docker is installed but not running. Start it (sudo systemctl start docker), then re-run: bash install.sh"
    fi
  fi
fi

PLAT=""
dc() {
  if [ "$USE_SUDO" = 1 ]; then
    if [ -n "$PLAT" ]; then sudo env DOCKER_DEFAULT_PLATFORM="$PLAT" docker compose "$@"; else sudo docker compose "$@"; fi
  else
    if [ -n "$PLAT" ]; then DOCKER_DEFAULT_PLATFORM="$PLAT" docker compose "$@"; else docker compose "$@"; fi
  fi
}
dc version >/dev/null 2>&1 || die "Docker Compose v2 is missing. Update Docker Desktop, or install the 'docker-compose-plugin' package."

# ---------------- 2. Ask for the key + write .env ----------------
getv() { [ -f .env ] && grep -E "^$1=" .env | head -1 | cut -d= -f2- | sed -E "s/^'(.*)'$/\1/" || true; }
dflt() { local v; v="$(getv "$1")"; echo "${v:-$2}"; }
rand() { (openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64) | tr '+/' '-_' | tr -d '=\n'; }
q()    { case "$1" in *[!A-Za-z0-9._/:@+=,-]*) printf "'%s'" "$1" ;; *) printf '%s' "$1" ;; esac; }

if ( : </dev/tty ) 2>/dev/null; then IN=/dev/tty; else IN=/dev/stdin; fi

OLD_KEY="$(getv OPENROUTER_API_KEY)"
KEY="${OPENROUTER_API_KEY:-}"
say "Configuration"
while [ -z "$KEY" ]; do
  if [ -n "$OLD_KEY" ]; then P="Enter OPENROUTER_API_KEY (required) [Enter = keep saved key]: "
  else P="Enter OPENROUTER_API_KEY (required, input hidden - paste and press Enter): "; fi
  read -rsp "$P" KEY <"$IN" || die "No input received. OPENROUTER_API_KEY is required."
  echo
  KEY="$(printf '%s' "$KEY" | tr -d '[:space:]')"
  [ -z "$KEY" ] && KEY="$OLD_KEY"
  [ -z "$KEY" ] && echo "OPENROUTER_API_KEY cannot be empty."
done
case "$KEY" in *\'*) die "The key must not contain a single quote (')." ;; esac

GRAFANA_PW="$(getv GRAFANA_ADMIN_PASSWORD)"; [ -n "$GRAFANA_PW" ] || GRAFANA_PW="$(rand | cut -c1-16)"
METRICS="$(getv METRICS_BEARER_TOKEN)";      [ -n "$METRICS" ]    || METRICS="$(rand)"

umask 077
cat > .env <<ENV
# ============================================================
#  Scheme Saathi settings  (created by install.sh)
#  Edit with any text editor, then apply with:
#      docker compose up -d
# ============================================================

# --- REQUIRED: your OpenRouter API key -----------------------
OPENROUTER_API_KEY=$(q "$KEY")

# --- Optional: OpenAI key (leave empty if unused) ------------
OPENAI_API_KEY=$(q "$(getv OPENAI_API_KEY)")

# --- AI models -----------------------------------------------
SUPERVISOR_MODEL=$(q "$(dflt SUPERVISOR_MODEL openai/gpt-4.1-mini)")
SPECIALIST_MODEL=$(q "$(dflt SPECIALIST_MODEL openai/gpt-4.1-mini)")

# --- Login (Auth0) -------------------------------------------
AUTH0_DOMAIN=$(q "$(dflt AUTH0_DOMAIN dev-pik1p86eoq2s0sbx.us.auth0.com)")
AUTH0_CLIENT_ID=$(q "$(dflt AUTH0_CLIENT_ID Mzk823q6jURSZvJPeLi5yq4JQykyv7o4)")
AUTH0_AUDIENCE=$(q "$(dflt AUTH0_AUDIENCE https://scheme-saathi-api)")
AUTH0_HOUSEHOLD_CLAIM=$(q "$(dflt AUTH0_HOUSEHOLD_CLAIM https://scheme-saathi/household_id)")
AUTH0_REDIRECT_URI=http://localhost:8501

# --- Dashboard (Grafana + Prometheus) - auto-generated -------
OBSERVABILITY_ENABLED=true
GRAFANA_ADMIN_PASSWORD=$(q "$GRAFANA_PW")
METRICS_BEARER_TOKEN=$(q "$METRICS")
ENV
printf '%s' "$METRICS" > prometheus/metrics_token
chmod 644 prometheus/metrics_token   # the Prometheus container must be able to read it

# ---------------- 3. Pull images and start ----------------
say "Pulling images from Docker Hub (this can take a few minutes)"
if ! dc pull; then
  echo "Pull failed - retrying with linux/amd64 images (needed on some ARM machines)..."
  PLAT="linux/amd64"
  dc pull || die "Could not pull images. Check your internet connection and that Docker is running."
fi

say "Starting containers"
dc up -d || die "Could not start containers. If a port is busy, free ports 8501, 3000 and 9090 and re-run."

say "Waiting for the apps to come up"
OK=1
if command -v curl >/dev/null 2>&1; then
  for url in http://localhost:8501 http://localhost:3000/login; do
    up=0
    for _ in $(seq 1 60); do curl -fsS -o /dev/null "$url" 2>/dev/null && { up=1; break; }; sleep 3; done
    [ "$up" = 1 ] || OK=0
  done
fi

cat <<DONE

============================================================
  Scheme Saathi installed successfully
============================================================
  Streamlit app : http://localhost:8501
  Grafana       : http://localhost:3000
                  login: admin / $GRAFANA_PW
============================================================
  Stop: docker compose down      Logs: docker compose logs -f
  Auth0: add http://localhost:8501 to Allowed Callback URLs.
DONE
[ "$OK" = 1 ] || echo "  (An app was slow to respond - give it a minute, or check: docker compose logs)"
exit 0
